# constants need by scripts
controlling=10.0.0.10
port=10035
authuser=test
authpassword=xyzzy
reponame=myrepl
#
agraphroot=/home/ec2-user/agraph
# compute our ip address
myip=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)

