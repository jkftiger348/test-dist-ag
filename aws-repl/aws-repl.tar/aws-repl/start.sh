. ./vars.sh
$agraphroot/bin/agraph-control --config $agraphroot/lib/agraph.cfg start
